
package main;

import pacote.AlunoPacote;
import privado.AlunoPrivado;
import protegido.AlunoProtegido;
import publico.AlunoPublico;


public class Main {
    public static void main(String[] args) {
        AlunoPacote aluno1 = new AlunoPacote(); //pacote e classe
        AlunoPrivado aluno2 = new AlunoPrivado(); //classe
        AlunoProtegido aluno3 = new AlunoProtegido(); //pac, clas, sub
        AlunoPublico aluno4 = new AlunoPublico(); //todos os locais
       
       aluno1.setNome("joao");
       aluno2.setNome("joao");
       aluno3.setNome("joao");
       aluno4.nome = "joao";
       
       //    Encapsulamento
       
        System.out.println("Aluno Pacote: "+aluno1.getNome());
        System.out.println("Aluno Privado: "+aluno2.getNome());
        System.out.println("Aluno Protegido: "+aluno3.getNome());
        System.out.println("Aluno Publico: "+aluno4.nome);
        
    }        
}
