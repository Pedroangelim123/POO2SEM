
package publico;

public class AlunoPublico {
    public String nome;
    public String cpf;

    
}

