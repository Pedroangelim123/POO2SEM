
package funcionario;


public class main {
    
    public static void calcularBonificacao(Funcionario f){
    f.bonificacao();
    if(f instanceof Gerente){
        System.out.println("Gerente " + if.getSalario()+ ff.getBonificacao());
    }else if(f instanceof Secretaria){
        System.out.println("Secretaria: "+(f.getSalario()+f.getBonificado());        
    }
    
    
    }
    public static void main(String[] args) {
          Gerente g = new Gerente();
          Secretaria s = new Secretaria();
          ServicoGerais sg = new ServicoGerais();
          
          g.setSalario(1000);
          g.setSalario(1000);
          g.setSalario(1000);
            
          calcularBonificacao(g);
          calcularBonificacao(s);
          calcularBonificacao(sg);
          
         
    }

   