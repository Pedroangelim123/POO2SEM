
package funcionario;


public abstract class Funcionario {
    
    
    private double salario;
    private double bonificado;

    public abstract void bonificacao();
    
    public double getSalario() {
        return salario;
    }

    
    public void setSalario(double salario) {
        this.salario = salario;
    }

   
    public double getBonificado() {
        return bonificado;
    }

    public void setBonificado(double bonificado) {
        this.bonificado = bonificado;
    }
    
    
}
